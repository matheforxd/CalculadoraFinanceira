import React from 'react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { TrendingDown } from 'lucide-react';

const CustomTooltip = ({ active, payload, label, formatCurrency }) => {
  if (active && payload && payload.length) {
    return (
      <div className="p-4 bg-card/80 backdrop-blur-sm border border-border rounded-lg shadow-lg text-sm">
        <p className="label font-bold text-lg text-foreground">{`Ano ${parseFloat(label).toFixed(1)}`}</p>
        <p className="intro text-red-400">{`Patrimônio: ${formatCurrency(payload[0].value)}`}</p>
        <p className="intro text-orange-400">{`Retirada Mensal: ${formatCurrency(payload[1].value)}`}</p>
        <p className="intro text-green-400">{`Rendimentos Mensais: ${formatCurrency(payload[2].value)}`}</p>
      </div>
    );
  }
  return null;
};

const WithdrawalSimulationChart = ({ goalAnalysis, results, formatCurrency }) => {
  if (!goalAnalysis || !results || goalAnalysis.isPerpetual) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: 0.3 }}
    >
      <Card className="bg-card/70 backdrop-blur-sm border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingDown className="text-red-400"/>
            Simulação de Retiradas Pós-Aportes
          </CardTitle>
          <CardDescription>
            Evolução do patrimônio durante {goalAnalysis.capitalDuration.toFixed(1)} anos de retiradas (após finalizar os aportes)
          </CardDescription>
        </CardHeader>
        <CardContent className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={goalAnalysis.withdrawalData} margin={{ top: 5, right: 20, left: 60, bottom: 5 }}>
              <defs>
                <linearGradient id="colorPatrimonio" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.7}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorRetirada" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.7}/>
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorRendimentos" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.7}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border)/0.5)" />
              <XAxis 
                dataKey="year" 
                stroke="hsl(var(--muted-foreground))" 
                tickFormatter={(tick) => `${parseFloat(tick).toFixed(0)}a`}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))" 
                tickFormatter={(value) => `R${(value/1000000).toFixed(1)}M`} 
              />
              <Tooltip content={<CustomTooltip formatCurrency={formatCurrency} />} />
              {goalAnalysis.inflectionPoint && (
                <ReferenceLine 
                  x={goalAnalysis.inflectionPoint} 
                  stroke="#fbbf24" 
                  strokeDasharray="5 5" 
                  strokeWidth={2}
                  label={{ 
                    value: "Rendimentos < Saques", 
                    position: "topLeft",
                    style: { fill: "#fbbf24", fontSize: "12px", fontWeight: "bold" }
                  }}
                />
              )}
              <Area 
                type="monotone" 
                dataKey="Patrimônio Restante" 
                name="Patrimônio Restante" 
                stroke="#ef4444" 
                fillOpacity={1} 
                fill="url(#colorPatrimonio)" 
                strokeWidth={2.5}
              />
              <Area 
                type="monotone" 
                dataKey="Retirada Mensal" 
                name="Retirada Mensal" 
                stroke="#f97316" 
                fillOpacity={1} 
                fill="url(#colorRetirada)" 
                strokeWidth={2.5}
              />
              <Area 
                type="monotone" 
                dataKey="Rendimentos Mensais" 
                name="Rendimentos Mensais" 
                stroke="#10b981" 
                fillOpacity={1} 
                fill="url(#colorRendimentos)" 
                strokeWidth={2.5}
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default WithdrawalSimulationChart;