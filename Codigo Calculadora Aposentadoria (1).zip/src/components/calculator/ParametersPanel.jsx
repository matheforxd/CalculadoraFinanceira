import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose, DialogDescription } from '@/components/ui/dialog';
import { Wallet, PiggyBank, Percent, Clock, User, Target, Goal, Edit, MinusCircle } from 'lucide-react';

const DetailedInputsDialog = ({ title, description, data, setData, unit, labelPrefix }) => {
    const handleUpdate = (id, value) => {
        const newData = data.map(item => item.id === id ? { ...item, [unit]: parseFloat(value) || 0 } : item);
        setData(newData);
    };

    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button variant="outline" className="w-full justify-start gap-2"><Edit className="h-4 w-4"/> {title}</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
                <DialogHeader>
                    <DialogTitle>{title}</DialogTitle>
                    <DialogDescription>{description}</DialogDescription>
                </DialogHeader>
                <div className="max-h-[60vh] overflow-y-auto pr-4 space-y-4">
                    {data.map(item => (
                        <div key={item.id} className="grid grid-cols-3 items-center gap-4">
                            <Label className="text-right">{labelPrefix} {item.year || item.month}</Label>
                            <Input 
                                type="number" 
                                value={item[unit]} 
                                onChange={(e) => handleUpdate(item.id, e.target.value)}
                                className="col-span-2"
                            />
                        </div>
                    ))}
                </div>
                <DialogFooter>
                    <DialogClose asChild>
                        <Button>Salvar</Button>
                    </DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

const ParametersPanel = ({
  activeTab, setActiveTab,
  initialValue, setInitialValue,
  contribution, setContribution,
  contributionFrequency, setContributionFrequency,
  interestRate, setInterestRate,
  interestRateType, setInterestRateType,
  duration, setDuration,
  durationUnit, setDurationUnit,
  currentAge, setCurrentAge,
  retirementAge, setRetirementAge,
  goalValue, setGoalValue,
  results, handleCalculate,
  adjustContributionsForInflation, setAdjustContributionsForInflation,
  simulationMode, setSimulationMode,
  detailedModeGranularity, setDetailedModeGranularity,
  annualInterestRates, setAnnualInterestRates,
  annualContributions, setAnnualContributions,
  annualInflationRates, setAnnualInflationRates,
  annualWithdrawals, setAnnualWithdrawals,
  monthlyInterestRates, setMonthlyInterestRates,
  monthlyContributions, setMonthlyContributions,
  monthlyInflationRates, setMonthlyInflationRates,
  monthlyWithdrawals, setMonthlyWithdrawals,
}) => (
    <Card className="bg-card/70 backdrop-blur-sm border-border/50">
        <CardHeader>
            <CardTitle className="flex items-center gap-2"><Wallet className="text-primary"/>Parâmetros</CardTitle>
            <CardDescription>Configure os dados para a sua simulação financeira.</CardDescription>
        </CardHeader>
        <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3 bg-secondary/50">
                    <TabsTrigger value="fixedPeriod" disabled={simulationMode === 'detailed'}>Período Fixo</TabsTrigger>
                    <TabsTrigger value="byAge" disabled={simulationMode === 'detailed'}>Por Idade</TabsTrigger>
                    <TabsTrigger value="goalValue" disabled={simulationMode === 'detailed'}>Por Meta</TabsTrigger>
                </TabsList>
                
                <div className="mt-6 space-y-5">
                    <div className="flex items-center justify-between rounded-lg border p-3 shadow-sm">
                        <div className="space-y-0.5">
                            <Label>Modo Detalhado</Label>
                            <CardDescription>Personalize aportes, juros e mais.</CardDescription>
                        </div>
                        <Switch checked={simulationMode === 'detailed'} onCheckedChange={(checked) => setSimulationMode(checked ? 'detailed' : 'simple')} />
                    </div>

                    <div className="space-y-2">
                        <Label>Capital Inicial</Label>
                        <div className="relative">
                            <PiggyBank className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/>
                            <Input value={initialValue} onChange={(e) => setInitialValue(e.target.value)} type="number" className="pl-10"/>
                        </div>
                    </div>

                    {simulationMode === 'simple' ? (
                        <>
                            <div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>Aportes</Label>
                                        <div className="relative">
                                            <PiggyBank className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/>
                                            <Input value={contribution} onChange={(e) => setContribution(e.target.value)} type="number" className="pl-10"/>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Frequência</Label>
                                        <Select value={contributionFrequency} onValueChange={setContributionFrequency}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="monthly">Mensal</SelectItem><SelectItem value="yearly">Anual</SelectItem></SelectContent></Select>
                                    </div>
                                </div>
                                <div className="flex items-center space-x-2 pt-2">
                                    <Checkbox id="adjust-inflation" checked={adjustContributionsForInflation} onCheckedChange={setAdjustContributionsForInflation} />
                                    <label htmlFor="adjust-inflation" className="text-sm text-muted-foreground leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">Corrigir aportes pela inflação</label>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Taxa de Juros (%)</Label>
                                    <div className="relative">
                                        <Percent className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/>
                                        <Input value={interestRate} onChange={(e) => setInterestRate(e.target.value)} type="number" className="pl-10"/>
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label>Tipo</Label>
                                    <Select value={interestRateType} onValueChange={setInterestRateType}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="yearly">Anual</SelectItem><SelectItem value="monthly">Mensal</SelectItem></SelectContent></Select>
                                </div>
                            </div>
                        </>
                    ) : (
                        <div className="space-y-3 rounded-lg border p-3">
                            <Tabs value={detailedModeGranularity} onValueChange={setDetailedModeGranularity}>
                                <TabsList className="grid w-full grid-cols-2">
                                    <TabsTrigger value="annual">Anual</TabsTrigger>
                                    <TabsTrigger value="monthly">Mensal</TabsTrigger>
                                </TabsList>
                                <TabsContent value="annual" className="space-y-3 pt-3">
                                    <DetailedInputsDialog title="Editar Aportes Anuais" description="Defina o valor do aporte para cada ano." data={annualContributions} setData={setAnnualContributions} unit="value" labelPrefix="Ano" />
                                    <DetailedInputsDialog title="Editar Retiradas Anuais" description="Defina retiradas pontuais para cada ano." data={annualWithdrawals} setData={setAnnualWithdrawals} unit="value" labelPrefix="Ano" />
                                    <DetailedInputsDialog title="Editar Juros Anuais (%)" description="Defina a taxa de juros anual para cada ano." data={annualInterestRates} setData={setAnnualInterestRates} unit="rate" labelPrefix="Ano" />
                                    <DetailedInputsDialog title="Editar Inflação Anual (%)" description="Defina a taxa de inflação anual para cada ano." data={annualInflationRates} setData={setAnnualInflationRates} unit="rate" labelPrefix="Ano" />
                                </TabsContent>
                                <TabsContent value="monthly" className="space-y-3 pt-3">
                                    <DetailedInputsDialog title="Editar Aportes Mensais" description="Defina o valor do aporte para cada mês." data={monthlyContributions} setData={setMonthlyContributions} unit="value" labelPrefix="Mês" />
                                    <DetailedInputsDialog title="Editar Retiradas Mensais" description="Defina retiradas pontuais para cada mês." data={monthlyWithdrawals} setData={setMonthlyWithdrawals} unit="value" labelPrefix="Mês" />
                                    <DetailedInputsDialog title="Editar Juros Mensais (%)" description="Defina a taxa de juros para cada mês." data={monthlyInterestRates} setData={setMonthlyInterestRates} unit="rate" labelPrefix="Mês" />
                                    <DetailedInputsDialog title="Editar Inflação Mensal (%)" description="Defina a taxa de inflação para cada mês." data={monthlyInflationRates} setData={setMonthlyInflationRates} unit="rate" labelPrefix="Mês" />
                                </TabsContent>
                            </Tabs>
                        </div>
                    )}

                    <TabsContent value="fixedPeriod" className="space-y-5 !mt-0">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label>Período</Label>
                                <div className="relative">
                                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/>
                                    <Input value={duration} onChange={(e) => setDuration(e.target.value)} type="number" className="pl-10"/>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label>Unidade</Label>
                                <Select value={durationUnit} onValueChange={setDurationUnit}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="years">Anos</SelectItem><SelectItem value="months">Meses</SelectItem></SelectContent></Select>
                            </div>
                        </div>
                    </TabsContent>
                    <TabsContent value="byAge" className="!mt-0">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label>Idade Atual</Label>
                                <div className="relative"><User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/><Input value={currentAge} onChange={(e) => setCurrentAge(e.target.value)} type="number" className="pl-10"/></div>
                            </div>
                            <div className="space-y-2">
                                <Label>Idade Aposentadoria</Label>
                                <div className="relative"><Target className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/><Input value={retirementAge} onChange={(e) => setRetirementAge(e.target.value)} type="number" className="pl-10"/></div>
                            </div>
                        </div>
                        <p className="text-center text-muted-foreground pt-4">Período de investimento: <span className="font-bold text-primary">{Math.max(0, retirementAge - currentAge)} anos</span></p>
                    </TabsContent>
                    <TabsContent value="goalValue" className="!mt-0">
                        <div className="space-y-2">
                            <Label>Meta de Valor (R$)</Label>
                            <div className="relative"><Goal className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/><Input value={goalValue} onChange={(e) => setGoalValue(e.target.value)} type="number" className="pl-10"/></div>
                        </div>
                        <p className="text-center text-muted-foreground pt-4">Tempo estimado: <span className="font-bold text-primary">{results ? parseFloat(results.totalTime).toFixed(1) : '...'} anos</span></p>
                    </TabsContent>
                </div>

                <motion.div whileTap={{ scale: 0.98 }}>
                    <Button size="lg" className="w-full mt-6" onClick={handleCalculate}>Calcular</Button>
                </motion.div>
            </Tabs>
        </CardContent>
    </Card>
);

export default ParametersPanel;