import React from 'react';
import { CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Flame, TrendingUp, PiggyBank, Zap, Target, HelpCircle, Percent, Clock } from 'lucide-react';
import { formatDisplayValue } from '@/lib/calculator-utils';

const AnalysisItem = ({ icon, label, value, description, valueClassName }) => (
    <div className="flex items-start space-x-4">
        <div className="p-2 bg-primary/10 rounded-md mt-1">{icon}</div>
        <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className={`font-bold text-lg ${valueClassName}`}>{value}</p>
            {description && <p className="text-xs text-muted-foreground">{description}</p>}
        </div>
    </div>
);

const AnalysisPanel = ({
    isGoalsAndInflation,
    isTips,
    passiveIncome,
    setPassiveIncome,
    inflationRate,
    setInflationRate,
    results,
    goalAnalysis,
    formatCurrency
}) => {
    if (isGoalsAndInflation) {
        return (
            <>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Flame className="text-primary"/>Metas e Inflação</CardTitle>
                    <CardDescription>Defina suas metas de aposentadoria.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label>Renda Passiva Mensal Desejada</Label>
                        <div className="relative">
                            <PiggyBank className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/>
                            <Input value={passiveIncome} onChange={(e) => setPassiveIncome(e.target.value)} type="number" className="pl-10"/>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label>Inflação Anual Média (%)</Label>
                        <div className="relative">
                            <TrendingUp className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground"/>
                            <Input value={inflationRate} onChange={(e) => setInflationRate(e.target.value)} type="number" className="pl-10"/>
                        </div>
                    </div>
                </CardContent>
            </>
        );
    }

    if (isTips) {
        return (
            <>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Zap className="text-primary"/>Dicas Rápidas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm text-muted-foreground">
                    <p><strong>Aportes constantes</strong> são a chave para o crescimento exponencial. Tente aumentá-los anualmente.</p>
                    <p>A <strong>taxa de juros</strong> tem um impacto enorme a longo prazo. Busque investimentos com boa rentabilidade.</p>
                    <p>A <strong>inflação</strong> corrói seu poder de compra. Sempre a considere em seus cálculos para ter uma visão realista.</p>
                </CardContent>
            </>
        );
    }

    if (!results || !goalAnalysis) {
        return (
            <CardContent className="flex items-center justify-center h-full">
                <p className="text-muted-foreground">Calcule para ver a análise.</p>
            </CardContent>
        );
    }

    return (
        <>
            <CardHeader>
                <CardTitle className="flex items-center gap-2"><Target className="text-primary"/>Análise de Meta de Renda</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <AnalysisItem
                    icon={<Target className="h-5 w-5 text-teal-400"/>}
                    label="Patrimônio para Renda Passiva (Hoje)"
                    value={isFinite(goalAnalysis.requiredCapital) ? formatDisplayValue(goalAnalysis.requiredCapital) : "Inalcançável"}
                    description="Capital necessário hoje para gerar sua renda passiva, com base na taxa de retirada ideal."
                    valueClassName="text-teal-400"
                />
                <AnalysisItem
                    icon={<HelpCircle className="h-5 w-5 text-green-400"/>}
                    label="Sua Meta Real no Futuro (Com Inflação)"
                    value={isFinite(goalAnalysis.requiredFutureCapital) ? formatDisplayValue(goalAnalysis.requiredFutureCapital) : "Inalcançável"}
                    description="Valor necessário na aposentadoria para gerar sua renda passiva desejada, corrigido pela inflação."
                    valueClassName="text-green-400"
                />
                <AnalysisItem
                    icon={<Percent className="h-5 w-5 text-cyan-400"/>}
                    label="Taxa de Retirada Anual Ideal"
                    value={`${(goalAnalysis.idealAnnualWithdrawalRate * 100).toFixed(2)}%`}
                    description="Taxa máxima para retiradas anuais que mantém seu patrimônio intacto (descontando a inflação)."
                    valueClassName="text-cyan-400"
                />
                <AnalysisItem
                    icon={<PiggyBank className="h-5 w-5 text-primary"/>}
                    label="Renda Passiva Mensal no Futuro"
                    value={formatDisplayValue(goalAnalysis.futurePassiveIncome)}
                    description={`Sua meta de ${formatCurrency(passiveIncome)} hoje, valerá isso no futuro.`}
                    valueClassName="text-primary"
                />
                <AnalysisItem
                    icon={<Clock className="h-5 w-5 text-amber-400"/>}
                    label="Duração do Patrimônio Acumulado"
                    value={goalAnalysis.isPerpetual ? "Vitalício ✨" : `${goalAnalysis.capitalDuration.toFixed(1)} anos`}
                    description="Tempo que seu patrimônio duraria com as retiradas mensais planejadas."
                    valueClassName="text-amber-400"
                />
            </CardContent>
        </>
    );
};

export default AnalysisPanel;