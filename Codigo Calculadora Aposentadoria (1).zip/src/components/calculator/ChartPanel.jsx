import React from 'react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { LineChart } from 'lucide-react';

const CustomTooltip = ({ active, payload, label, formatCurrency }) => {
  if (active && payload && payload.length) {
    return (
      <div className="p-4 bg-card/80 backdrop-blur-sm border border-border rounded-lg shadow-lg text-sm">
        <p className="label font-bold text-lg text-foreground">{`Ano ${parseFloat(label).toFixed(1)}`}</p>
        <p className="intro text-primary">{`Valor Bruto: ${formatCurrency(payload[0].value)}`}</p>
        <p className="intro text-green-400">{`Poder de Compra: ${formatCurrency(payload[1].value)}`}</p>
        <p className="intro text-blue-400">{`Total Investido: ${formatCurrency(payload[2].value)}`}</p>
      </div>
    );
  }
  return null;
};

const ChartPanel = ({ chartData, formatCurrency }) => (
  <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: 0.2 }}
  >
      <Card className="bg-card/70 backdrop-blur-sm border-border/50">
          <CardHeader>
              <CardTitle className="flex items-center gap-2"><LineChart className="text-primary"/>Evolução do Patrimônio</CardTitle>
              <CardDescription>Acompanhe o crescimento do seu investimento ao longo do tempo</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 5, right: 20, left: 60, bottom: 5 }}>
                      <defs>
                          <linearGradient id="colorBruto" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.7}/><stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/></linearGradient>
                          <linearGradient id="colorReal" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#10b981" stopOpacity={0.7}/><stop offset="95%" stopColor="#10b981" stopOpacity={0}/></linearGradient>
                          <linearGradient id="colorInvestido" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#3b82f6" stopOpacity={0.7}/><stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/></linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border)/0.5)" />
                      <XAxis dataKey="year" stroke="hsl(var(--muted-foreground))" tickFormatter={(tick) => parseFloat(tick).toFixed(0)} unit="a" />
                      <YAxis stroke="hsl(var(--muted-foreground))" tickFormatter={(value) => `R$${(value/1000).toFixed(0)}k`} />
                      <Tooltip content={<CustomTooltip formatCurrency={formatCurrency} />} />
                      <Area type="monotone" dataKey="Valor Acumulado" name="Valor Bruto" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorBruto)" strokeWidth={2.5}/>
                      <Area type="monotone" dataKey="Poder de Compra Real" name="Poder de Compra Real" stroke="#10b981" fillOpacity={1} fill="url(#colorReal)" strokeWidth={2.5}/>
                      <Area type="monotone" dataKey="Total Investido" name="Total Investido" stroke="#3b82f6" fillOpacity={1} fill="url(#colorInvestido)" strokeWidth={2.5}/>
                  </AreaChart>
              </ResponsiveContainer>
          </CardContent>
      </Card>
  </motion.div>
);

export default ChartPanel;