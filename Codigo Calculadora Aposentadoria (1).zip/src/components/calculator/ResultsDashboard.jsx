import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { formatDisplayValue } from '@/lib/calculator-utils';

const ResultsDashboard = ({ results }) => (
  <AnimatePresence>
    {results && (
        <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4"
        >
            <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-center">
                <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Valor Final Bruto</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-lg sm:text-xl lg:text-2xl font-bold text-primary break-words leading-tight">
                        {formatDisplayValue(results.finalNominalValue)}
                    </p>
                </CardContent>
            </Card>
            <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-center">
                <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Poder de Compra Real</CardTitle>
                    <CardDescription className="text-xs">Valor ajustado pela inflação</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-lg sm:text-xl lg:text-2xl font-bold text-green-400 break-words leading-tight">
                        {formatDisplayValue(results.finalRealValue)}
                    </p>
                </CardContent>
            </Card>
            <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-center">
                <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Total em Juros</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-lg sm:text-xl lg:text-2xl font-bold text-cyan-400 break-words leading-tight">
                        {formatDisplayValue(results.totalInterest)}
                    </p>
                </CardContent>
            </Card>
            <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-center">
                <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Tempo Total</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-lg sm:text-xl lg:text-2xl font-bold break-words leading-tight">
                        {parseFloat(results.totalTime).toFixed(1)} anos
                    </p>
                </CardContent>
            </Card>
        </motion.div>
    )}
  </AnimatePresence>
);

export default ResultsDashboard;