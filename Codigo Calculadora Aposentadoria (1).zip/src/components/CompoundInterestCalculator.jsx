import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { useToast } from "@/components/ui/use-toast";
import { Calculator, Download } from 'lucide-react';
import { runSimulation, formatCurrency } from '@/lib/calculator-utils';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { v4 as uuidv4 } from 'uuid';
import { Button } from '@/components/ui/button';
import { exportToPDF } from '@/utils/pdfExport';

import ParametersPanel from '@/components/calculator/ParametersPanel';
import ResultsDashboard from '@/components/calculator/ResultsDashboard';
import ChartPanel from '@/components/calculator/ChartPanel';
import WithdrawalSimulationChart from '@/components/calculator/WithdrawalSimulationChart';
import AnalysisPanel from '@/components/calculator/AnalysisPanel';

export default function CompoundInterestCalculator() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useLocalStorage('calculator_activeTab', 'fixedPeriod');
  
  const [initialValue, setInitialValue] = useLocalStorage('calculator_initialValue', '10000');
  const [contribution, setContribution] = useLocalStorage('calculator_contribution', '500');
  const [contributionFrequency, setContributionFrequency] = useLocalStorage('calculator_contributionFrequency', 'monthly');
  const [interestRate, setInterestRate] = useLocalStorage('calculator_interestRate', '12');
  const [interestRateType, setInterestRateType] = useLocalStorage('calculator_interestRateType', 'yearly');
  const [duration, setDuration] = useLocalStorage('calculator_duration', '10');
  const [durationUnit, setDurationUnit] = useLocalStorage('calculator_durationUnit', 'years');
  const [inflationRate, setInflationRate] = useLocalStorage('calculator_inflationRate', '5');
  
  const [currentAge, setCurrentAge] = useLocalStorage('calculator_currentAge', '30');
  const [retirementAge, setRetirementAge] = useLocalStorage('calculator_retirementAge', '60');
  const [goalValue, setGoalValue] = useLocalStorage('calculator_goalValue', '1000000');

  const [passiveIncome, setPassiveIncome] = useLocalStorage('calculator_passiveIncome', '5000');
  
  const [adjustContributionsForInflation, setAdjustContributionsForInflation] = useLocalStorage('calculator_adjustContributionsForInflation', true);
  const [simulationMode, setSimulationMode] = useLocalStorage('calculator_simulationMode', 'simple');
  const [detailedModeGranularity, setDetailedModeGranularity] = useLocalStorage('calculator_detailedModeGranularity', 'annual');

  const [annualInterestRates, setAnnualInterestRates] = useLocalStorage('calculator_annualInterestRates', []);
  const [annualContributions, setAnnualContributions] = useLocalStorage('calculator_annualContributions', []);
  const [annualInflationRates, setAnnualInflationRates] = useLocalStorage('calculator_annualInflationRates', []);
  const [annualWithdrawals, setAnnualWithdrawals] = useLocalStorage('calculator_annualWithdrawals', []);
  const [monthlyInterestRates, setMonthlyInterestRates] = useLocalStorage('calculator_monthlyInterestRates', []);
  const [monthlyContributions, setMonthlyContributions] = useLocalStorage('calculator_monthlyContributions', []);
  const [monthlyInflationRates, setMonthlyInflationRates] = useLocalStorage('calculator_monthlyInflationRates', []);
  const [monthlyWithdrawals, setMonthlyWithdrawals] = useLocalStorage('calculator_monthlyWithdrawals', []);

  const [results, setResults] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [goalAnalysis, setGoalAnalysis] = useState(null);

  const getYears = useCallback(() => {
    if (activeTab === 'fixedPeriod') {
      return durationUnit === 'years' ? parseInt(duration) || 0 : Math.floor((parseInt(duration) || 0) / 12);
    }
    if (activeTab === 'byAge') {
      return Math.max(0, (parseInt(retirementAge) || 0) - (parseInt(currentAge) || 0));
    }
    return parseInt(duration) || 0;
  }, [activeTab, duration, durationUnit, retirementAge, currentAge]);

  const getMonths = useCallback(() => {
    if (activeTab === 'fixedPeriod') {
        return durationUnit === 'years' ? (parseInt(duration) || 0) * 12 : parseInt(duration) || 0;
    }
    if (activeTab === 'byAge') {
        return Math.max(0, (parseInt(retirementAge) || 0) - (parseInt(currentAge) || 0)) * 12;
    }
    return (parseInt(duration) || 0) * 12;
  }, [activeTab, duration, durationUnit, retirementAge, currentAge]);

  const syncSimpleToDetailed = useCallback(() => {
    const years = getYears();
    const months = getMonths();
    const contributionValue = parseFloat(contribution) || 0;
    const interestRateValue = parseFloat(interestRate) || 0;
    const inflationRateValue = parseFloat(inflationRate) || 0;

    let annualContributionValue, monthlyContributionValue;
    if (contributionFrequency === 'monthly') {
      monthlyContributionValue = contributionValue;
      annualContributionValue = contributionValue * 12;
    } else {
      annualContributionValue = contributionValue;
      monthlyContributionValue = contributionValue / 12;
    }

    let annualInterestRateValue, monthlyInterestRateValue;
    if (interestRateType === 'yearly') {
      annualInterestRateValue = interestRateValue;
      monthlyInterestRateValue = ((1 + interestRateValue / 100) ** (1/12) - 1) * 100;
    } else {
      monthlyInterestRateValue = interestRateValue;
      annualInterestRateValue = ((1 + interestRateValue / 100) ** 12 - 1) * 100;
    }

    const newAnnualContributions = Array.from({ length: years }, (_, i) => ({
      id: annualContributions[i]?.id || uuidv4(),
      year: i + 1,
      value: annualContributionValue
    }));
    setAnnualContributions(newAnnualContributions);

    const newMonthlyContributions = Array.from({ length: months }, (_, i) => ({
      id: monthlyContributions[i]?.id || uuidv4(),
      month: i + 1,
      value: monthlyContributionValue
    }));
    setMonthlyContributions(newMonthlyContributions);

    const newAnnualInterestRates = Array.from({ length: years }, (_, i) => ({
      id: annualInterestRates[i]?.id || uuidv4(),
      year: i + 1,
      rate: annualInterestRateValue
    }));
    setAnnualInterestRates(newAnnualInterestRates);

    const newMonthlyInterestRates = Array.from({ length: months }, (_, i) => ({
      id: monthlyInterestRates[i]?.id || uuidv4(),
      month: i + 1,
      rate: monthlyInterestRateValue
    }));
    setMonthlyInterestRates(newMonthlyInterestRates);

    const newAnnualInflationRates = Array.from({ length: years }, (_, i) => ({
      id: annualInflationRates[i]?.id || uuidv4(),
      year: i + 1,
      rate: inflationRateValue
    }));
    setAnnualInflationRates(newAnnualInflationRates);

    const monthlyInflationRateFromAnnual = ((1 + inflationRateValue / 100) ** (1/12) - 1) * 100;
    const newMonthlyInflationRates = Array.from({ length: months }, (_, i) => ({
      id: monthlyInflationRates[i]?.id || uuidv4(),
      month: i + 1,
      rate: monthlyInflationRateFromAnnual
    }));
    setMonthlyInflationRates(newMonthlyInflationRates);

    const newAnnualWithdrawals = Array.from({ length: years }, (_, i) => 
      annualWithdrawals[i] || { id: uuidv4(), year: i + 1, value: 0 }
    );
    setAnnualWithdrawals(newAnnualWithdrawals);

    const newMonthlyWithdrawals = Array.from({ length: months }, (_, i) => 
      monthlyWithdrawals[i] || { id: uuidv4(), month: i + 1, value: 0 }
    );
    setMonthlyWithdrawals(newMonthlyWithdrawals);

  }, [
    getYears, getMonths, contribution, contributionFrequency, interestRate, interestRateType, inflationRate,
    annualContributions, monthlyContributions, annualInterestRates, monthlyInterestRates,
    annualInflationRates, monthlyInflationRates, annualWithdrawals, monthlyWithdrawals,
    setAnnualContributions, setMonthlyContributions, setAnnualInterestRates, setMonthlyInterestRates,
    setAnnualInflationRates, setMonthlyInflationRates, setAnnualWithdrawals, setMonthlyWithdrawals
  ]);

  useEffect(() => {
    syncSimpleToDetailed();
  }, [duration, durationUnit, retirementAge, currentAge, activeTab, contribution, contributionFrequency, interestRate, interestRateType, inflationRate]);

  const handleCalculate = useCallback(() => {
    const simulationParams = {
      P: parseFloat(initialValue) || 0,
      A: parseFloat(contribution) || 0,
      contributionFrequency,
      annualInterestRate: parseFloat(interestRate) || 0,
      interestRateType,
      duration: parseFloat(duration) || 0,
      durationUnit,
      annualInflationRate: parseFloat(inflationRate) / 100 || 0,
      passiveIncome: parseFloat(passiveIncome) || 0,
      adjustContributionsForInflation,
      simulationMode,
      detailedModeGranularity,
      annualInterestRates,
      annualContributions,
      annualInflationRates,
      annualWithdrawals,
      monthlyInterestRates,
      monthlyContributions,
      monthlyInflationRates,
      monthlyWithdrawals,
    };

    let yearsToSimulate = getYears();

    if (activeTab === 'byAge') {
        setDuration(yearsToSimulate.toString());
        setDurationUnit('years');
    }

    const { results: simResults, chartData: simChartData, goalAnalysis: simGoalAnalysis } = runSimulation(
        activeTab, 
        simulationParams, 
        yearsToSimulate,
        parseFloat(goalValue) || 0,
        toast
    );

    if(simResults && simChartData && simGoalAnalysis) {
        if (activeTab === 'goalValue' && simulationMode === 'simple') {
            setDuration(simResults.totalTime.toFixed(1));
            setDurationUnit('years');
        }
        setResults(simResults);
        setChartData(simChartData);
        setGoalAnalysis(simGoalAnalysis);
    }
  }, [
    initialValue, contribution, contributionFrequency, interestRate, interestRateType, duration, durationUnit, inflationRate, 
    passiveIncome, activeTab, retirementAge, currentAge, goalValue, toast, adjustContributionsForInflation,
    simulationMode, detailedModeGranularity, annualInterestRates, annualContributions, annualInflationRates, annualWithdrawals,
    monthlyInterestRates, monthlyContributions, monthlyInflationRates, monthlyWithdrawals, getYears, setDuration, setDurationUnit
  ]);
  
  useEffect(() => {
    handleCalculate();
  }, []);

  const handleExportPDF = async () => {
    toast({ title: "Gerando PDF...", description: "Aguarde um momento, estamos preparando seu relatório." });
    
    const htmlElement = document.documentElement;
    const wasDark = htmlElement.classList.contains('dark');

    try {
      if (wasDark) {
        htmlElement.classList.remove('dark');
      }
      
      await new Promise(resolve => setTimeout(resolve, 100));

      const success = await exportToPDF('dashboard-to-export', 'relatorio-financeiro.pdf');
      if (success) {
        toast({ title: "Sucesso!", description: "Seu relatório em PDF foi gerado e o download deve começar em breve.", className: "bg-green-500 text-white" });
      }
    } catch (error) {
      toast({ title: "Erro ao gerar PDF", description: "Não foi possível gerar o relatório. Tente novamente.", variant: "destructive" });
    } finally {
      if (wasDark) {
        htmlElement.classList.add('dark');
      }
    }
  };

  const parametersProps = {
    activeTab, setActiveTab,
    initialValue, setInitialValue,
    contribution, setContribution,
    contributionFrequency, setContributionFrequency,
    interestRate, setInterestRate,
    interestRateType, setInterestRateType,
    duration, setDuration,
    durationUnit, setDurationUnit,
    currentAge, setCurrentAge,
    retirementAge, setRetirementAge,
    goalValue, setGoalValue,
    results, handleCalculate,
    adjustContributionsForInflation, setAdjustContributionsForInflation,
    simulationMode, setSimulationMode,
    detailedModeGranularity, setDetailedModeGranularity,
    annualInterestRates, setAnnualInterestRates,
    annualContributions, setAnnualContributions,
    annualInflationRates, setAnnualInflationRates,
    annualWithdrawals, setAnnualWithdrawals,
    monthlyInterestRates, setMonthlyInterestRates,
    monthlyContributions, setMonthlyContributions,
    monthlyInflationRates, setMonthlyInflationRates,
    monthlyWithdrawals, setMonthlyWithdrawals,
  };

  const goalsAndInflationProps = {
    passiveIncome, setPassiveIncome,
    inflationRate, setInflationRate,
  };

  return (
    <div className="bg-background min-h-screen w-full text-foreground relative overflow-hidden">
        <div className="absolute top-0 left-[-20%] w-[140%] h-[120vh] bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))]"></div>
        <main className="container mx-auto px-4 py-8 md:px-8 md:py-12 relative z-10">
            <header className="text-center mb-12">
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="flex items-center justify-between gap-4 flex-wrap"
                >
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
                      <Calculator className="h-8 w-8 text-primary" />
                    </div>
                    <div className="text-left">
                      <h1 className="text-3xl md:text-5xl font-bold text-foreground">
                        Calculadora de Juros Compostos
                      </h1>
                      <p className="text-lg text-muted-foreground mt-1">Planeje seu futuro financeiro com precisão e clareza.</p>
                    </div>
                  </div>
                  <Button onClick={handleExportPDF} className="bg-primary/80 hover:bg-primary">
                    <Download className="mr-2 h-4 w-4" />
                    Exportar PDF
                  </Button>
                </motion.div>
            </header>

            <div className="grid grid-cols-12 gap-6">
                <motion.div 
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.7 }}
                  className="col-span-12 lg:col-span-4"
                >
                    <ParametersPanel {...parametersProps} />
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.7, delay: 0.2 }}
                        className="mt-6"
                    >
                        <Card className="bg-card/70 backdrop-blur-sm border-border/50">
                            <AnalysisPanel {...goalsAndInflationProps} isGoalsAndInflation={true} />
                        </Card>
                    </motion.div>
                </motion.div>

                <div id="dashboard-to-export" className="col-span-12 lg:col-span-8 space-y-6">
                    <ResultsDashboard results={results} />
                    <ChartPanel chartData={chartData} formatCurrency={formatCurrency} />
                    <WithdrawalSimulationChart 
                        goalAnalysis={goalAnalysis} 
                        results={results} 
                        formatCurrency={formatCurrency} 
                    />
                    <motion.div
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.7, delay: 0.4 }}
                        className="grid grid-cols-1 md:grid-cols-2 gap-6"
                    >
                        <Card className="bg-card/70 backdrop-blur-sm border-border/50">
                            <AnalysisPanel results={results} goalAnalysis={goalAnalysis} formatCurrency={formatCurrency} isGoalsAndInflation={false} passiveIncome={passiveIncome}/>
                        </Card>
                        <Card className="bg-card/70 backdrop-blur-sm border-border/50">
                            <AnalysisPanel isTips={true} />
                        </Card>
                    </motion.div>
                </div>
            </div>
        </main>
    </div>
  );
}