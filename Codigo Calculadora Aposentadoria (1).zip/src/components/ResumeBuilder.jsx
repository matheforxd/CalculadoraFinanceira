import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Briefcase, 
  GraduationCap, 
  Award, 
  Download, 
  Eye, 
  Edit3, 
  Plus, 
  Trash2, 
  Upload,
  Palette,
  FileText,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/components/ui/use-toast';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { exportToPDF } from '@/utils/pdfExport';

const colorSchemes = {
  blue: {
    primary: '#3B82F6',
    secondary: '#1E40AF',
    accent: '#60A5FA',
    text: '#1F2937'
  },
  purple: {
    primary: '#8B5CF6',
    secondary: '#7C3AED',
    accent: '#A78BFA',
    text: '#1F2937'
  },
  green: {
    primary: '#10B981',
    secondary: '#059669',
    accent: '#34D399',
    text: '#1F2937'
  },
  orange: {
    primary: '#F59E0B',
    secondary: '#D97706',
    accent: '#FBBF24',
    text: '#1F2937'
  },
  pink: {
    primary: '#EC4899',
    secondary: '#DB2777',
    accent: '#F472B6',
    text: '#1F2937'
  }
};

const templates = {
  modern: 'Moderno',
  classic: 'Clássico',
  creative: 'Criativo'
};

export default function ResumeBuilder() {
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  const [isPreview, setIsPreview] = useState(false);
  
  const [resumeData, setResumeData] = useLocalStorage('resumeData', {
    personalInfo: {
      name: '',
      title: '',
      email: '',
      phone: '',
      location: '',
      summary: '',
      photo: null
    },
    experiences: [],
    education: [],
    skills: [],
    template: 'modern',
    colorScheme: 'blue'
  });

  const updatePersonalInfo = (field, value) => {
    setResumeData(prev => ({
      ...prev,
      personalInfo: { ...prev.personalInfo, [field]: value }
    }));
  };

  const addExperience = () => {
    const newExperience = {
      id: Date.now(),
      company: '',
      position: '',
      startDate: '',
      endDate: '',
      description: '',
      current: false
    };
    setResumeData(prev => ({
      ...prev,
      experiences: [...prev.experiences, newExperience]
    }));
  };

  const updateExperience = (id, field, value) => {
    setResumeData(prev => ({
      ...prev,
      experiences: prev.experiences.map(exp => 
        exp.id === id ? { ...exp, [field]: value } : exp
      )
    }));
  };

  const removeExperience = (id) => {
    setResumeData(prev => ({
      ...prev,
      experiences: prev.experiences.filter(exp => exp.id !== id)
    }));
  };

  const addEducation = () => {
    const newEducation = {
      id: Date.now(),
      institution: '',
      degree: '',
      startDate: '',
      endDate: '',
      description: ''
    };
    setResumeData(prev => ({
      ...prev,
      education: [...prev.education, newEducation]
    }));
  };

  const updateEducation = (id, field, value) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.map(edu => 
        edu.id === id ? { ...edu, [field]: value } : edu
      )
    }));
  };

  const removeEducation = (id) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.filter(edu => edu.id !== id)
    }));
  };

  const addSkill = () => {
    const newSkill = {
      id: Date.now(),
      name: '',
      level: 50
    };
    setResumeData(prev => ({
      ...prev,
      skills: [...prev.skills, newSkill]
    }));
  };

  const updateSkill = (id, field, value) => {
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.map(skill => 
        skill.id === id ? { ...skill, [field]: value } : skill
      )
    }));
  };

  const removeSkill = (id) => {
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill.id !== id)
    }));
  };

  const handlePhotoUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Arquivo muito grande",
          description: "Por favor, selecione uma imagem menor que 5MB.",
          variant: "destructive"
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        updatePersonalInfo('photo', e.target.result);
        toast({
          title: "Foto carregada!",
          description: "Sua foto de perfil foi adicionada com sucesso."
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleExportPDF = async () => {
    try {
      await exportToPDF('resume-preview', `${resumeData.personalInfo.name || 'curriculo'}.pdf`);
      toast({
        title: "PDF exportado!",
        description: "Seu currículo foi salvo com sucesso."
      });
    } catch (error) {
      toast({
        title: "Erro na exportação",
        description: "Não foi possível exportar o PDF. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  const currentColorScheme = colorSchemes[resumeData.colorScheme];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-bold gradient-text mb-4 font-display">
            Construtor de Currículos
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Crie um currículo profissional e impressionante em minutos com nossos templates modernos
          </p>
        </motion.div>

        <div className="flex justify-center mb-8">
          <div className="glass-effect rounded-lg p-2">
            <div className="flex gap-2">
              <Button
                onClick={() => setIsPreview(false)}
                variant={!isPreview ? "default" : "ghost"}
                className="flex items-center gap-2"
              >
                <Edit3 className="w-4 h-4" />
                Editar
              </Button>
              <Button
                onClick={() => setIsPreview(true)}
                variant={isPreview ? "default" : "ghost"}
                className="flex items-center gap-2"
              >
                <Eye className="w-4 h-4" />
                Visualizar
              </Button>
              <Button
                onClick={handleExportPDF}
                variant="outline"
                className="flex items-center gap-2 bg-green-500 text-white hover:bg-green-600"
              >
                <Download className="w-4 h-4" />
                Exportar PDF
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <AnimatePresence mode="wait">
            {!isPreview ? (
              <motion.div
                key="editor"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <Card className="glass-effect border-0">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Palette className="w-5 h-5" />
                      Personalização
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Template</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {Object.entries(templates).map(([key, name]) => (
                          <Button
                            key={key}
                            variant={resumeData.template === key ? "default" : "outline"}
                            size="sm"
                            onClick={() => setResumeData(prev => ({ ...prev, template: key }))}
                          >
                            {name}
                          </Button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Esquema de Cores</Label>
                      <div className="flex gap-2">
                        {Object.entries(colorSchemes).map(([key, scheme]) => (
                          <button
                            key={key}
                            onClick={() => setResumeData(prev => ({ ...prev, colorScheme: key }))}
                            className={`w-8 h-8 rounded-full border-2 ${
                              resumeData.colorScheme === key ? 'border-gray-800' : 'border-gray-300'
                            }`}
                            style={{ backgroundColor: scheme.primary }}
                          />
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Tabs defaultValue="personal" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="personal" className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      Pessoal
                    </TabsTrigger>
                    <TabsTrigger value="experience" className="flex items-center gap-1">
                      <Briefcase className="w-4 h-4" />
                      Experiência
                    </TabsTrigger>
                    <TabsTrigger value="education" className="flex items-center gap-1">
                      <GraduationCap className="w-4 h-4" />
                      Educação
                    </TabsTrigger>
                    <TabsTrigger value="skills" className="flex items-center gap-1">
                      <Award className="w-4 h-4" />
                      Habilidades
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="personal">
                    <Card>
                      <CardHeader>
                        <CardTitle>Informações Pessoais</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex flex-col items-center gap-4">
                          <div className="relative">
                            {resumeData.personalInfo.photo ? (
                              <img
                                src={resumeData.personalInfo.photo}
                                alt="Foto de perfil"
                                className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                              />
                            ) : (
                              <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center">
                                <User className="w-8 h-8 text-gray-400" />
                              </div>
                            )}
                            <Button
                              size="sm"
                              className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0"
                              onClick={() => fileInputRef.current?.click()}
                            >
                              <Upload className="w-4 h-4" />
                            </Button>
                            <input
                              ref={fileInputRef}
                              type="file"
                              accept="image/*"
                              onChange={handlePhotoUpload}
                              className="hidden"
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="name">Nome Completo</Label>
                            <Input
                              id="name"
                              value={resumeData.personalInfo.name}
                              onChange={(e) => updatePersonalInfo('name', e.target.value)}
                              placeholder="Seu nome completo"
                            />
                          </div>
                          <div>
                            <Label htmlFor="title">Título Profissional</Label>
                            <Input
                              id="title"
                              value={resumeData.personalInfo.title}
                              onChange={(e) => updatePersonalInfo('title', e.target.value)}
                              placeholder="Ex: Desenvolvedor Frontend"
                            />
                          </div>
                          <div>
                            <Label htmlFor="email">Email</Label>
                            <Input
                              id="email"
                              type="email"
                              value={resumeData.personalInfo.email}
                              onChange={(e) => updatePersonalInfo('email', e.target.value)}
                              placeholder="seu@email.com"
                            />
                          </div>
                          <div>
                            <Label htmlFor="phone">Telefone</Label>
                            <Input
                              id="phone"
                              value={resumeData.personalInfo.phone}
                              onChange={(e) => updatePersonalInfo('phone', e.target.value)}
                              placeholder="(11) 99999-9999"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <Label htmlFor="location">Localização</Label>
                          <Input
                            id="location"
                            value={resumeData.personalInfo.location}
                            onChange={(e) => updatePersonalInfo('location', e.target.value)}
                            placeholder="Cidade, Estado"
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="summary">Resumo Profissional</Label>
                          <Textarea
                            id="summary"
                            value={resumeData.personalInfo.summary}
                            onChange={(e) => updatePersonalInfo('summary', e.target.value)}
                            placeholder="Descreva brevemente sua experiência e objetivos profissionais..."
                            rows={4}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="experience">
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle>Experiência Profissional</CardTitle>
                        <Button onClick={addExperience} size="sm">
                          <Plus className="w-4 h-4 mr-2" />
                          Adicionar
                        </Button>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {resumeData.experiences.map((exp) => (
                          <motion.div
                            key={exp.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="p-4 border rounded-lg space-y-3"
                          >
                            <div className="flex justify-between items-start">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 flex-1">
                                <Input
                                  value={exp.company}
                                  onChange={(e) => updateExperience(exp.id, 'company', e.target.value)}
                                  placeholder="Nome da empresa"
                                />
                                <Input
                                  value={exp.position}
                                  onChange={(e) => updateExperience(exp.id, 'position', e.target.value)}
                                  placeholder="Cargo"
                                />
                                <Input
                                  type="date"
                                  value={exp.startDate}
                                  onChange={(e) => updateExperience(exp.id, 'startDate', e.target.value)}
                                />
                                <Input
                                  type="date"
                                  value={exp.endDate}
                                  onChange={(e) => updateExperience(exp.id, 'endDate', e.target.value)}
                                  disabled={exp.current}
                                />
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeExperience(exp.id)}
                                className="text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                            <Textarea
                              value={exp.description}
                              onChange={(e) => updateExperience(exp.id, 'description', e.target.value)}
                              placeholder="Descreva suas responsabilidades e conquistas..."
                              rows={3}
                            />
                          </motion.div>
                        ))}
                        {resumeData.experiences.length === 0 && (
                          <div className="text-center py-8 text-gray-500">
                            <Briefcase className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>Nenhuma experiência adicionada ainda</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="education">
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle>Educação</CardTitle>
                        <Button onClick={addEducation} size="sm">
                          <Plus className="w-4 h-4 mr-2" />
                          Adicionar
                        </Button>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {resumeData.education.map((edu) => (
                          <motion.div
                            key={edu.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="p-4 border rounded-lg space-y-3"
                          >
                            <div className="flex justify-between items-start">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 flex-1">
                                <Input
                                  value={edu.institution}
                                  onChange={(e) => updateEducation(edu.id, 'institution', e.target.value)}
                                  placeholder="Nome da instituição"
                                />
                                <Input
                                  value={edu.degree}
                                  onChange={(e) => updateEducation(edu.id, 'degree', e.target.value)}
                                  placeholder="Curso/Grau"
                                />
                                <Input
                                  type="date"
                                  value={edu.startDate}
                                  onChange={(e) => updateEducation(edu.id, 'startDate', e.target.value)}
                                />
                                <Input
                                  type="date"
                                  value={edu.endDate}
                                  onChange={(e) => updateEducation(edu.id, 'endDate', e.target.value)}
                                />
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeEducation(edu.id)}
                                className="text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                            <Textarea
                              value={edu.description}
                              onChange={(e) => updateEducation(edu.id, 'description', e.target.value)}
                              placeholder="Descrição adicional (opcional)..."
                              rows={2}
                            />
                          </motion.div>
                        ))}
                        {resumeData.education.length === 0 && (
                          <div className="text-center py-8 text-gray-500">
                            <GraduationCap className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>Nenhuma educação adicionada ainda</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="skills">
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle>Habilidades</CardTitle>
                        <Button onClick={addSkill} size="sm">
                          <Plus className="w-4 h-4 mr-2" />
                          Adicionar
                        </Button>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {resumeData.skills.map((skill) => (
                          <motion.div
                            key={skill.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="p-4 border rounded-lg space-y-3"
                          >
                            <div className="flex items-center gap-3">
                              <Input
                                value={skill.name}
                                onChange={(e) => updateSkill(skill.id, 'name', e.target.value)}
                                placeholder="Nome da habilidade"
                                className="flex-1"
                              />
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeSkill(skill.id)}
                                className="text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span>Nível</span>
                                <span>{skill.level}%</span>
                              </div>
                              <Slider
                                value={[skill.level]}
                                onValueChange={(value) => updateSkill(skill.id, 'level', value[0])}
                                max={100}
                                step={5}
                                className="w-full"
                              />
                            </div>
                          </motion.div>
                        ))}
                        {resumeData.skills.length === 0 && (
                          <div className="text-center py-8 text-gray-500">
                            <Award className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>Nenhuma habilidade adicionada ainda</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </motion.div>
            ) : null}
          </AnimatePresence>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className={`${!isPreview ? 'lg:block' : 'col-span-full'}`}
          >
            <div className="sticky top-8">
              <Card className="resume-shadow border-0 overflow-hidden">
                <CardContent className="p-0">
                  <div id="resume-preview" className="bg-white">
                    <ResumePreview data={resumeData} colorScheme={currentColorScheme} />
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function ResumePreview({ data, colorScheme }) {
  const { personalInfo, experiences, education, skills, template } = data;

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
  };

  if (template === 'modern') {
    return (
      <div className="min-h-[297mm] bg-white text-gray-800" style={{ fontFamily: 'Inter, sans-serif' }}>
        {/* Header */}
        <div 
          className="p-8 text-white relative overflow-hidden"
          style={{ backgroundColor: colorScheme.primary }}
        >
          <div className="absolute inset-0 opacity-10">
            <div className="absolute -top-4 -right-4 w-32 h-32 rounded-full" style={{ backgroundColor: colorScheme.accent }}></div>
            <div className="absolute -bottom-8 -left-8 w-40 h-40 rounded-full" style={{ backgroundColor: colorScheme.secondary }}></div>
          </div>
          <div className="relative z-10 flex items-center gap-6">
            {personalInfo.photo && (
              <img
                src={personalInfo.photo}
                alt="Foto de perfil"
                className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
              />
            )}
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">{personalInfo.name || 'Seu Nome'}</h1>
              <h2 className="text-xl opacity-90 mb-3">{personalInfo.title || 'Seu Título Profissional'}</h2>
              <div className="flex flex-wrap gap-4 text-sm opacity-80">
                {personalInfo.email && <span>📧 {personalInfo.email}</span>}
                {personalInfo.phone && <span>📱 {personalInfo.phone}</span>}
                {personalInfo.location && <span>📍 {personalInfo.location}</span>}
              </div>
            </div>
          </div>
        </div>

        <div className="p-8 grid grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="col-span-2 space-y-6">
            {/* Summary */}
            {personalInfo.summary && (
              <section>
                <h3 className="text-xl font-semibold mb-3 pb-2 border-b-2" style={{ borderColor: colorScheme.primary, color: colorScheme.primary }}>
                  Resumo Profissional
                </h3>
                <p className="text-gray-700 leading-relaxed">{personalInfo.summary}</p>
              </section>
            )}

            {/* Experience */}
            {experiences.length > 0 && (
              <section>
                <h3 className="text-xl font-semibold mb-4 pb-2 border-b-2" style={{ borderColor: colorScheme.primary, color: colorScheme.primary }}>
                  Experiência Profissional
                </h3>
                <div className="space-y-4">
                  {experiences.map((exp) => (
                    <div key={exp.id} className="relative pl-6">
                      <div className="absolute left-0 top-2 w-3 h-3 rounded-full" style={{ backgroundColor: colorScheme.accent }}></div>
                      <div className="absolute left-1.5 top-5 w-0.5 h-full" style={{ backgroundColor: colorScheme.accent, opacity: 0.3 }}></div>
                      <div>
                        <h4 className="font-semibold text-lg">{exp.position}</h4>
                        <p className="font-medium" style={{ color: colorScheme.secondary }}>{exp.company}</p>
                        <p className="text-sm text-gray-500 mb-2">
                          {formatDate(exp.startDate)} - {exp.current ? 'Atual' : formatDate(exp.endDate)}
                        </p>
                        {exp.description && <p className="text-gray-700 leading-relaxed">{exp.description}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Education */}
            {education.length > 0 && (
              <section>
                <h3 className="text-xl font-semibold mb-4 pb-2 border-b-2" style={{ borderColor: colorScheme.primary, color: colorScheme.primary }}>
                  Educação
                </h3>
                <div className="space-y-3">
                  {education.map((edu) => (
                    <div key={edu.id}>
                      <h4 className="font-semibold">{edu.degree}</h4>
                      <p className="font-medium" style={{ color: colorScheme.secondary }}>{edu.institution}</p>
                      <p className="text-sm text-gray-500">
                        {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                      </p>
                      {edu.description && <p className="text-gray-700 text-sm mt-1">{edu.description}</p>}
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Skills */}
            {skills.length > 0 && (
              <section>
                <h3 className="text-lg font-semibold mb-4 pb-2 border-b-2" style={{ borderColor: colorScheme.primary, color: colorScheme.primary }}>
                  Habilidades
                </h3>
                <div className="space-y-3">
                  {skills.map((skill) => (
                    <div key={skill.id}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-medium">{skill.name}</span>
                        <span className="text-gray-500">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="h-2 rounded-full transition-all duration-300"
                          style={{ 
                            width: `${skill.level}%`,
                            backgroundColor: colorScheme.primary 
                          }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (template === 'classic') {
    return (
      <div className="min-h-[297mm] bg-white text-gray-800 p-8" style={{ fontFamily: 'Inter, sans-serif' }}>
        {/* Header */}
        <div className="text-center mb-8 pb-6 border-b-2" style={{ borderColor: colorScheme.primary }}>
          {personalInfo.photo && (
            <img
              src={personalInfo.photo}
              alt="Foto de perfil"
              className="w-20 h-20 rounded-full object-cover mx-auto mb-4 border-2"
              style={{ borderColor: colorScheme.primary }}
            />
          )}
          <h1 className="text-3xl font-bold mb-2" style={{ color: colorScheme.primary }}>
            {personalInfo.name || 'Seu Nome'}
          </h1>
          <h2 className="text-lg text-gray-600 mb-3">{personalInfo.title || 'Seu Título Profissional'}</h2>
          <div className="flex justify-center gap-6 text-sm text-gray-600">
            {personalInfo.email && <span>{personalInfo.email}</span>}
            {personalInfo.phone && <span>{personalInfo.phone}</span>}
            {personalInfo.location && <span>{personalInfo.location}</span>}
          </div>
        </div>

        {/* Summary */}
        {personalInfo.summary && (
          <section className="mb-6">
            <h3 className="text-lg font-semibold mb-3 uppercase tracking-wide" style={{ color: colorScheme.primary }}>
              Resumo Profissional
            </h3>
            <p className="text-gray-700 leading-relaxed">{personalInfo.summary}</p>
          </section>
        )}

        {/* Experience */}
        {experiences.length > 0 && (
          <section className="mb-6">
            <h3 className="text-lg font-semibold mb-4 uppercase tracking-wide" style={{ color: colorScheme.primary }}>
              Experiência Profissional
            </h3>
            <div className="space-y-4">
              {experiences.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-start mb-1">
                    <h4 className="font-semibold text-lg">{exp.position}</h4>
                    <span className="text-sm text-gray-500">
                      {formatDate(exp.startDate)} - {exp.current ? 'Atual' : formatDate(exp.endDate)}
                    </span>
                  </div>
                  <p className="font-medium mb-2" style={{ color: colorScheme.secondary }}>{exp.company}</p>
                  {exp.description && <p className="text-gray-700 leading-relaxed">{exp.description}</p>}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Education */}
        {education.length > 0 && (
          <section className="mb-6">
            <h3 className="text-lg font-semibold mb-4 uppercase tracking-wide" style={{ color: colorScheme.primary }}>
              Educação
            </h3>
            <div className="space-y-3">
              {education.map((edu) => (
                <div key={edu.id}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold">{edu.degree}</h4>
                      <p className="font-medium" style={{ color: colorScheme.secondary }}>{edu.institution}</p>
                    </div>
                    <span className="text-sm text-gray-500">
                      {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                    </span>
                  </div>
                  {edu.description && <p className="text-gray-700 text-sm mt-1">{edu.description}</p>}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Skills */}
        {skills.length > 0 && (
          <section>
            <h3 className="text-lg font-semibold mb-4 uppercase tracking-wide" style={{ color: colorScheme.primary }}>
              Habilidades
            </h3>
            <div className="grid grid-cols-2 gap-4">
              {skills.map((skill) => (
                <div key={skill.id} className="flex items-center gap-3">
                  <span className="font-medium flex-1">{skill.name}</span>
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className="w-3 h-3 rounded-full"
                        style={{
                          backgroundColor: i < Math.round(skill.level / 20) ? colorScheme.primary : '#e5e7eb'
                        }}
                      ></div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    );
  }

  if (template === 'creative') {
    return (
      <div className="min-h-[297mm] bg-white text-gray-800" style={{ fontFamily: 'Inter, sans-serif' }}>
        <div className="grid grid-cols-5 min-h-full">
          {/* Sidebar */}
          <div className="col-span-2 p-6 text-white relative overflow-hidden" style={{ backgroundColor: colorScheme.primary }}>
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 w-32 h-32 rounded-full transform translate-x-16 -translate-y-16" style={{ backgroundColor: colorScheme.accent }}></div>
              <div className="absolute bottom-0 left-0 w-40 h-40 rounded-full transform -translate-x-20 translate-y-20" style={{ backgroundColor: colorScheme.secondary }}></div>
            </div>
            
            <div className="relative z-10">
              {personalInfo.photo && (
                <div className="text-center mb-6">
                  <img
                    src={personalInfo.photo}
                    alt="Foto de perfil"
                    className="w-32 h-32 rounded-full object-cover mx-auto border-4 border-white shadow-lg"
                  />
                </div>
              )}

              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3 pb-2 border-b border-white/30">
                    Contato
                  </h3>
                  <div className="space-y-2 text-sm">
                    {personalInfo.email && (
                      <div className="flex items-center gap-2">
                        <span>📧</span>
                        <span>{personalInfo.email}</span>
                      </div>
                    )}
                    {personalInfo.phone && (
                      <div className="flex items-center gap-2">
                        <span>📱</span>
                        <span>{personalInfo.phone}</span>
                      </div>
                    )}
                    {personalInfo.location && (
                      <div className="flex items-center gap-2">
                        <span>📍</span>
                        <span>{personalInfo.location}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Skills */}
                {skills.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3 pb-2 border-b border-white/30">
                      Habilidades
                    </h3>
                    <div className="space-y-3">
                      {skills.map((skill) => (
                        <div key={skill.id}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="font-medium">{skill.name}</span>
                            <span className="opacity-80">{skill.level}%</span>
                          </div>
                          <div className="w-full bg-white/20 rounded-full h-2">
                            <div
                              className="h-2 rounded-full bg-white transition-all duration-300"
                              style={{ width: `${skill.level}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="col-span-3 p-8">
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-2 font-display" style={{ color: colorScheme.primary }}>
                {personalInfo.name || 'Seu Nome'}
              </h1>
              <h2 className="text-xl text-gray-600 mb-4">{personalInfo.title || 'Seu Título Profissional'}</h2>
              {personalInfo.summary && (
                <p className="text-gray-700 leading-relaxed">{personalInfo.summary}</p>
              )}
            </div>

            {/* Experience */}
            {experiences.length > 0 && (
              <section className="mb-8">
                <h3 className="text-2xl font-bold mb-4 font-display" style={{ color: colorScheme.primary }}>
                  Experiência
                </h3>
                <div className="space-y-6">
                  {experiences.map((exp) => (
                    <div key={exp.id} className="relative">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: colorScheme.accent }}>
                          <Briefcase className="w-5 h-5" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-bold text-lg">{exp.position}</h4>
                          <p className="font-semibold" style={{ color: colorScheme.secondary }}>{exp.company}</p>
                          <p className="text-sm text-gray-500 mb-2">
                            {formatDate(exp.startDate)} - {exp.current ? 'Atual' : formatDate(exp.endDate)}
                          </p>
                          {exp.description && <p className="text-gray-700 leading-relaxed">{exp.description}</p>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Education */}
            {education.length > 0 && (
              <section>
                <h3 className="text-2xl font-bold mb-4 font-display" style={{ color: colorScheme.primary }}>
                  Educação
                </h3>
                <div className="space-y-4">
                  {education.map((edu) => (
                    <div key={edu.id} className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: colorScheme.accent }}>
                        <GraduationCap className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold">{edu.degree}</h4>
                        <p className="font-semibold" style={{ color: colorScheme.secondary }}>{edu.institution}</p>
                        <p className="text-sm text-gray-500">
                          {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                        </p>
                        {edu.description && <p className="text-gray-700 text-sm mt-1">{edu.description}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    );
  }

  return null;
}