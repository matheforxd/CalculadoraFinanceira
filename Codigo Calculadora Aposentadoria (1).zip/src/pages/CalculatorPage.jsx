import React from 'react';
import CompoundInterestCalculator from '@/components/CompoundInterestCalculator';

export default function CalculatorPage() {
  return <CompoundInterestCalculator />;
}