import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { CheckCircle, BarChart, Target, Shield, Zap, Star, TrendingUp, BrainCircuit, Users, Calculator, Settings, Clock, DollarSign, PieChart, Layers, Eye, Gauge } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const FeatureCard = ({ icon, title, children }) => (
  <motion.div
    className="flex items-start space-x-4"
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.5 }}
    transition={{ duration: 0.5 }}
  >
    <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
      {icon}
    </div>
    <div>
      <h3 className="text-lg font-bold text-foreground">{title}</h3>
      <p className="text-muted-foreground mt-1">{children}</p>
    </div>
  </motion.div>
);

const TestimonialCard = ({ name, role, children, imageText }) => (
  <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-left">
    <CardContent className="p-6">
      <div className="flex items-center mb-4">
        <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
          <span className="text-xl font-bold text-primary">{imageText}</span>
        </div>
        <div>
          <p className="font-bold text-foreground">{name}</p>
          <p className="text-sm text-muted-foreground">{role}</p>
        </div>
      </div>
      <p className="text-muted-foreground">"{children}"</p>
    </CardContent>
  </Card>
);

const FeatureShowcase = ({ title, description, imageSrc, imageAlt, reverse = false }) => (
  <motion.div
    className={`grid md:grid-cols-2 gap-12 items-center ${reverse ? 'md:grid-flow-col-dense' : ''}`}
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.3 }}
    transition={{ duration: 0.6 }}
  >
    <div className={reverse ? 'md:col-start-2' : ''}>
      <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">{title}</h3>
      <p className="text-lg text-muted-foreground leading-relaxed">{description}</p>
    </div>
    <div className={reverse ? 'md:col-start-1' : ''}>
      <Card className="bg-card/50 backdrop-blur-lg border-border/30 shadow-xl overflow-hidden">
        <img  alt={imageAlt} className="w-full h-auto object-cover" src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
      </Card>
    </div>
  </motion.div>
);

export default function SalesPage() {
  const { toast } = useToast();

  const handleBuyClick = () => {
    toast({
      title: "🚀 Lançamento em Breve!",
      description: "A funcionalidade de compra ainda não está disponível, mas estamos preparando tudo para você!",
      variant: "default",
    });
  };

  return (
    <div className="bg-background text-foreground w-full overflow-x-hidden">
      <div className="absolute top-0 left-0 w-full h-[120vh] bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))] -z-10"></div>
      
      <header className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <BarChart className="h-8 w-8 text-primary" />
          <span className="text-xl font-bold">Finance Pro</span>
        </div>
        <Button asChild>
          <Link to="/calculator">Acessar Calculadora</Link>
        </Button>
      </header>

      <main>
        <section className="container mx-auto px-4 pt-20 pb-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-400">
              Pare de Adivinhar. Assuma o Controle Total do Seu Futuro Financeiro.
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground">
              A única calculadora de juros compostos que simula a vida real, com a precisão que você precisa para alcançar a liberdade financeira mais rápido.
            </p>
            <div className="mt-10 flex justify-center gap-4">
              <Button size="lg" className="text-lg" onClick={handleBuyClick}>
                <Zap className="mr-2 h-5 w-5" /> Quero o Controle Total
              </Button>
            </div>
          </motion.div>

          <motion.div 
            className="mt-16 max-w-4xl mx-auto"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Card className="bg-card/50 backdrop-blur-lg border-border/30 shadow-2xl shadow-primary/10 overflow-hidden">
              <img  alt="Dashboard principal da calculadora financeira mostrando gráficos e resultados" className="w-full h-auto object-cover" src="https://images.unsplash.com/photo-1644995722044-6cd197ffb440" />
            </Card>
          </motion.div>
        </section>

        <section className="py-24 bg-secondary/30">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Sua Realidade Financeira, Simulada com Perfeição.</h2>
              <p className="mt-4 text-lg text-muted-foreground">Chega de planilhas genéricas. Nossa ferramenta foi criada para quem leva o futuro a sério.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
              <FeatureCard icon={<BrainCircuit size={24} />} title="Simulação Detalhada">
                Ajuste aportes, juros e inflação mês a mês ou ano a ano. Sua vida não é linear, seu planejamento também não deveria ser.
              </FeatureCard>
              <FeatureCard icon={<TrendingUp size={24} />} title="Projeção com Inflação">
                Veja seu poder de compra real no futuro. Saiba exatamente quanto seu dinheiro valerá e planeje com base na realidade.
              </FeatureCard>
              <FeatureCard icon={<Target size={24} />} title="Análise de Metas Inteligente">
                Defina sua meta de renda passiva e descubra o patrimônio necessário, já corrigido pela inflação. Tenha um alvo claro.
              </FeatureCard>
              <FeatureCard icon={<Shield size={24} />} title="Duração do Patrimônio">
                Descubra por quanto tempo seu dinheiro realmente duraria com as retiradas planejadas. Sem surpresas desagradáveis.
              </FeatureCard>
              <FeatureCard icon={<Users size={24} />} title="Múltiplos Cenários">
                Simule seu futuro por período fixo, por idade de aposentadoria ou pelo tempo necessário para atingir uma meta de valor.
              </FeatureCard>
              <FeatureCard icon={<BarChart size={24} />} title="Visualização Intuitiva">
                Gráficos e dashboards claros que transformam números complexos em insights fáceis de entender e acionar.
              </FeatureCard>
            </div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-20">
              <h2 className="text-3xl md:text-4xl font-bold">Funcionalidades que Fazem a Diferença</h2>
              <p className="mt-4 text-lg text-muted-foreground">Cada recurso foi pensado para dar a você o máximo de controle e precisão no seu planejamento financeiro.</p>
            </div>

            <div className="space-y-24">
              <FeatureShowcase
                title="Dashboard de Resultados em Tempo Real"
                description="Veja instantaneamente o valor final bruto, poder de compra real, total em juros e tempo necessário. Todos os números que importam, organizados de forma clara e visual. Nunca mais se perca em cálculos complexos - tudo fica cristalino em segundos."
                imageSrc="Modern financial dashboard showing real-time investment results with colorful charts and key metrics"
                imageAlt="Dashboard mostrando resultados financeiros em tempo real"
              />

              <FeatureShowcase
                title="Modo Detalhado: Controle Total Mês a Mês"
                description="A vida real não é uma linha reta. Com o Modo Detalhado, você pode ajustar aportes, juros e inflação para cada mês ou ano individualmente. Simule bônus, 13º salário, variações de mercado ou qualquer cenário específico. É o planejamento mais realista que existe."
                imageSrc="Detailed financial planning interface with monthly and yearly input controls and customization options"
                imageAlt="Interface do modo detalhado com controles mensais e anuais"
                reverse={true}
              />

              <FeatureShowcase
                title="Gráficos Evolutivos Inteligentes"
                description="Acompanhe visualmente a evolução do seu patrimônio ao longo do tempo. Veja a diferença entre valor bruto e poder de compra real, compare com o total investido e identifique os pontos de aceleração do crescimento. Uma imagem vale mais que mil números."
                imageSrc="Interactive financial growth charts showing investment evolution over time with multiple data lines"
                imageAlt="Gráficos interativos mostrando evolução do investimento"
              />

              <FeatureShowcase
                title="Análise de Metas e Renda Passiva"
                description="Defina sua meta de renda passiva mensal e descubra exatamente quanto patrimônio você precisa acumular. A ferramenta calcula automaticamente o valor corrigido pela inflação e mostra quanto tempo seu dinheiro duraria com as retiradas planejadas. Planejamento baseado em objetivos reais."
                imageSrc="Goal analysis interface showing passive income calculations and wealth duration projections"
                imageAlt="Interface de análise de metas e renda passiva"
                reverse={true}
              />

              <FeatureShowcase
                title="Três Modos de Simulação Poderosos"
                description="Planeje por período fixo, por idade de aposentadoria ou pelo tempo necessário para atingir uma meta específica. Cada modo foi otimizado para diferentes estratégias de planejamento, dando a você a flexibilidade total para modelar seu futuro exatamente como você imagina."
                imageSrc="Multiple simulation modes interface showing different planning approaches and scenarios"
                imageAlt="Interface com múltiplos modos de simulação"
              />
            </div>
          </div>
        </section>

        <section className="py-24 bg-secondary/30">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Por Que Esta Calculadora é Única?</h2>
              <p className="mt-4 text-lg text-muted-foreground">Veja o que nos diferencia de qualquer outra ferramenta do mercado.</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-center p-6">
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calculator size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2">Precisão Matemática</h3>
                <p className="text-muted-foreground">Algoritmos avançados que consideram juros compostos, inflação e variações temporais com precisão científica.</p>
              </Card>

              <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-center p-6">
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Settings size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2">Personalização Total</h3>
                <p className="text-muted-foreground">Ajuste cada parâmetro individualmente. Nenhuma outra ferramenta oferece este nível de controle granular.</p>
              </Card>

              <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-center p-6">
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Eye size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2">Transparência Total</h3>
                <p className="text-muted-foreground">Veja exatamente como cada cálculo é feito. Sem caixas pretas, sem mistérios, apenas clareza absoluta.</p>
              </Card>

              <Card className="bg-card/70 backdrop-blur-sm border-border/50 text-center p-6">
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Gauge size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2">Performance Instantânea</h3>
                <p className="text-muted-foreground">Resultados em tempo real, sem espera. Teste cenários infinitos e veja os resultados instantaneamente.</p>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold">Não Acredite Apenas na Nossa Palavra</h2>
              <p className="mt-4 text-lg text-muted-foreground">Veja o que planejadores e usuários como você estão dizendo.</p>
            </div>
            <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <TestimonialCard name="Juliana S." role="Desenvolvedora de Software" imageText="JS">
                "Finalmente uma ferramenta que entende as minhas variações de renda como freelancer. O modo detalhado é simplesmente genial. Pela primeira vez, sinto que meu plano de aposentadoria é real."
              </TestimonialCard>
              <TestimonialCard name="Marcos P." role="Engenheiro" imageText="MP">
                "A análise de 'duração do patrimônio' foi um divisor de águas. Me deu a confiança que eu precisava para saber que meu plano é sólido e alcançável. Recomendo para todos!"
              </TestimonialCard>
              <TestimonialCard name="Carla R." role="Pequena Empresária" imageText="CR">
                "Eu costumava me perder em planilhas. Esta calculadora tornou tudo visual, simples e poderoso. Em 10 minutos, entendi mais sobre meu futuro do que em 10 anos tentando sozinha."
              </TestimonialCard>
            </div>
          </div>
        </section>

        <section className="py-24 bg-secondary/30">
          <div className="container mx-auto px-4 max-w-3xl">
            <div className="text-center">
              <h2 className="text-3xl md:text-4xl font-bold">Perguntas Frequentes</h2>
            </div>
            <Accordion type="single" collapsible className="w-full mt-12">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-lg">Para quem é esta calculadora?</AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground">
                  É para qualquer pessoa que leva a sério o planejamento financeiro. Desde jovens profissionais começando a investir, freelancers com renda variável, até pessoas próximas da aposentadoria que precisam de uma visão clara e realista do seu futuro.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger className="text-lg">O que a torna diferente de outras calculadoras?</AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground">
                  A profundidade e o realismo. Nenhuma outra ferramenta permite que você detalhe aportes, juros e inflação de forma mensal e anual, e ainda calcule a duração exata do seu patrimônio. Nós simulamos a vida real, não uma fantasia.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger className="text-lg">Como funciona o Modo Detalhado?</AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground">
                  No Modo Detalhado, você pode personalizar aportes, juros, inflação e retiradas para cada mês ou ano individualmente. Isso permite simular cenários realistas como bônus anuais, variações de mercado, mudanças de emprego ou qualquer situação específica da sua vida financeira.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger className="text-lg">A calculadora considera a inflação?</AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground">
                  Sim, e de forma muito avançada. Além de calcular o poder de compra real do seu patrimônio futuro, a ferramenta pode corrigir automaticamente seus aportes pela inflação e permite definir taxas de inflação diferentes para cada período. Você vê tanto o valor nominal quanto o valor real do seu dinheiro.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger className="text-lg">O pagamento é único ou uma assinatura?</AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground">
                  O acesso à Calculadora Financeira Pro é através de um pagamento único. Você paga uma vez e tem acesso vitalício a todas as funcionalidades e futuras atualizações. Sem mensalidades, sem surpresas.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4">
            <Card className="bg-gradient-to-br from-primary to-purple-600 text-primary-foreground p-8 md:p-12 text-center shadow-2xl shadow-primary/30">
              <h2 className="text-3xl md:text-5xl font-extrabold">Pronto para Tomar as Rédeas do Seu Futuro?</h2>
              <p className="mt-4 max-w-2xl mx-auto text-lg md:text-xl text-primary-foreground/80">
                Chega de incertezas. Tenha clareza, confiança e um plano à prova de futuro. Seu eu do futuro agradecerá.
              </p>
              <div className="mt-10">
                <Button size="lg" variant="secondary" className="text-lg" onClick={handleBuyClick}>
                  <Zap className="mr-2 h-5 w-5" /> Sim, Quero Acesso Vitalício Agora!
                </Button>
              </div>
            </Card>
          </div>
        </section>
      </main>

      <footer className="border-t border-border/30">
        <div className="container mx-auto px-4 py-6 text-center text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Finance Pro. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}